/** url固定头 */
var headUrl = 'http://localhost:8080/Inventory';
var fixParam = {
	plateformCode : 2
};

/** 表单验证结果 */
var validationResult = false;

/**
 * 验证是否登陆
 */
function loginValidator() {
	if(!$.cookie('admin')) {
		swal({
	        title: "请先登陆。",
	        text: '',
	        type: "warning",
	        showCancelButton: false,
	        confirmButtonColor: "#DD6B55",
	        confirmButtonText: "Yes",
	        closeOnConfirm: true
	    }, function () {
	    //	window.location.href="http://42.51.32.69:8080/Inventory/manage/views/admin/login.html";
	    });
		return false;
	}
	return true;
}

/**
 * 刷新datatables
 */
function shuaxin(table) {
	table.ajax.reload(null, false);
}

/**
 *补0
 *num 数字
 *n 位数
 */
function plusZero(num, n) {
    if ((num + "").length >= n) {
        return num;
    }
    return plusZero("0" + num, n);
}

/**
 * 进行表单验证
 * @param id
 */
function runValidator(id) {
	$('#'+id).bootstrapValidator('validate');
	if(validationResult) {
		validationResult = false
		return !validationResult;
	} else {
		return validationResult;
	}
}

/**
 * 清除表单验证
 * @param id
 * @param methodName
 */
function addValidator(id, methodName) {
	validator(id, methodName);
	$('#'+id).data('bootstrapValidator').resetForm(true);
    $('#'+id).data('bootstrapValidator').destroy();
    $('#'+id).data('bootstrapValidator', null);
    validator(id, methodName);
}

/**
 * 上传文件
 */
function ajaxFileUpload(dirType, obj, modal, name){
	if($("#" + modal).val() != ""){
		$.ajaxFileUpload({
			url : '/Inventory/file/add/up', //用于文件上传的服务器端请求地址
			secureuri : false, //是否需要安全协议，一般设置为false
			fileElementId : modal, //文件上传域的ID
			dataType : 'json', //返回值类型 一般设置为json
			data:{
				fileType: dirType
			},
			success : function(json, status) //服务器成功响应处理函数
			{
				setTimeout(function() {
					window.clearInterval(oTimer);
				}, 500);
				json = json.split('>')[1].split('<')[0];
				json = JSON.parse(json);
				if(json.code == '00001'){
					var data = json.data;
				//	$("#" + modal + " #imageUrl").attr('src', data.filePath);
					var value = '';
					$.each(data, function(i, item){
						value += ';' + item.filePath;
					})
					$("#" + obj).val(value.substring(1));
					if (typeof (data.error) != 'undefined') {
						if (data.error != '') {
							alert(data.error);
						} else {
							alert(data.message);
						}
					}
					var start = new method(name);	//初始化需要执行的方法
					start.func();	//执行
				}else{
					swal({
	    			  title: "错误！",
	    			  type: "error",
	    			  timer: 2000,
	    			  showConfirmButton: false,
		    		});
				}
			},
			error : function(data, status, e)//服务器响应失败处理函数
			{
			//console.log(data);
			window.clearInterval(oTimer);
			alert(e);
			}
		});
	} else {
		swal({
			  title: "请选择文件",
			  type: "error",
			  timer: 1000,
			  showConfirmButton: false,
  		});
	}
}

/**
 * 上传文件
 */
function fileUpload(dirType, obj, methodName){
	if($("#" + obj).val() != ""){
		$.ajaxFileUpload({
			url : 'http://42.51.32.69:8080/clock/file/add/up', //用于文件上传的服务器端请求地址
			secureuri : false, //是否需要安全协议，一般设置为false
			fileElementId : obj, //文件上传域的ID
			dataType : 'json', //返回值类型 一般设置为json
			data:{
				fileType: dirType,
				plateformCode : 2,
				uSign : $.cookie('aId')
			},
			success : function(json, status) //服务器成功响应处理函数
			{
				if(json.code == 1){
					var data = json.data[0];
					if (typeof (data.error) != 'undefined') {
						if (data.error != '') {
							alert(data.error);
						} else {
							alert(data.message);
						}
					}
					$("#" + obj).val("");
					var start = new method(methodName);	//初始化需要执行的方法
					start.func(data.filePath);	//执行
				}else{
					swal({
	    			  title: json.message,
	    			  type: "error",
	    			  timer: 2000,
	    			  showConfirmButton: false,
		    		});
				}
			},
			error : function(data, status, e)//服务器响应失败处理函数
			{
				alert(e);
			}
		});
	} else {
		swal({
			  title: "请选择文件",
			  type: "error",
			  timer: 1000,
			  showConfirmButton: false,
  		});
	}
}

/**
 * post 请求（添加）
 * @param url 接口路径
 * @param param 参数对象
 * @param fnCallback 返回结果（正常）
 * @param fnErrorCallback 返回结果（错误）
 */
$.postAjax = function(url, param, fnCallback, fnErrorCallback) {
	url = headUrl + url;
	param = param || {};
	param = $.extend(param, fixParam);
	if (fnCallback && typeof fnCallback == "function") {
		$.post(url, param, function(json, status) {
			if (status == "success") {
				fnCallback(json);
			} else if (fnErrorCallback && typeof fnErrorCallback == "function") {
				fnErrorCallback();
			}
		});
	}
};

/**
 * get 请求（获取）
 * @param url 接口路径
 * @param param 参数对象
 * @param fnCallback 返回结果（正常）
 * @param fnErrorCallback 返回结果（错误）
 */
$.getAjax = function(url, param, fnCallback, fnErrorCallback) {
	url = headUrl + url;
	param = param || {};
	param = $.extend(param, fixParam);
	if (fnCallback && typeof fnCallback == "function") {
		$.get(url, param, function(json, status) {
			if (status == "success") {
				fnCallback(json);
			} else if (fnErrorCallback && typeof fnErrorCallback == "function") {
				fnErrorCallback();
			}
		})
	}
};

/**
 * put 请求（修改）
 * @param url 接口路径
 * @param param 参数对象
 * @param fnCallback 返回结果（正常）
 * @param fnErrorCallback 返回结果（错误）
 */
$.putAjax = function(url, param, fnCallback, fnErrorCallback) {
	url = headUrl + url;
	param = param || {};
	param = $.extend(param, fixParam);
	if (fnCallback && typeof fnCallback == "function") {
		$.put(url, param, function(json, status) {
			if (status == "success") {
				var data = JSON.parse(json);
				fnCallback(data);
			} else if (fnErrorCallback
					&& typeof fnErrorCallback == "function") {
				fnErrorCallback();
			}
		})
	}
};

/**
 * delete 请求（删除）
 * @param url 接口路径
 * @param param 参数对象
 * @param fnCallback 返回结果（正常）
 * @param fnErrorCallback 返回结果（错误）
 */
$.deleteAjax = function(url, param, fnCallback, fnErrorCallback) {
	url = headUrl + url;
	param = param || {};
	param = $.extend(param, fixParam);
	if (fnCallback && typeof fnCallback == "function") {
		$.del(url, param, function(json, status) {
			if (status == "success") {
				var data = JSON.parse(json);
				fnCallback(data);
			} else if (fnErrorCallback
					&& typeof fnErrorCallback == "function") {
				fnErrorCallback();
			}
		})
	}
};

var util = {

	getParam : function(key) {
		var search = window.location.search;
		if (!search)
			return "";
		var params = search.substring(1).split("&");
		for ( var index in params) {
			var param = params[index].split("=");
			if (param[0] == key)
				return param[1];
		}
		return "";
	},

	getFormValue : function(fromId) {// 传入表单ID
		var frm = document.getElementById(fromId);// 获取表单对象
		var name, value, row = "";
		if (frm.elements.length) {
			for (var i = 0; i < frm.length; i++) {// 遍历每个表单元素
				var obj = frm[i];
				if (obj.type != "submit" && obj.type != "reset"
						&& obj.type != "button") {
					if (obj.type == "radio" || obj.type == "checkbox") {
						if (obj.checked) {
							name = obj.name;
							value = obj.value;
							row = row + name + "=" + value + "&";
						}
					} else {
						name = obj.name;
						value = obj.value;
						row = row + name + "=" + value + "&";
					}
				}
			}
		}
		return row;
	},

	/*
	 * 获取form序列化后的字段值
	 */
	formParam : function(key) {
		var obj = {};
		var params = key.split("&");
		for ( var i in params) {
			var param = params[i].split("=");
			for ( var j in param) {
				obj[param[0]] = param[1];
			}
		}
		return obj;
	},

	/*
	 * getByteLen:function(ss) { var re; re= ^.{10}$; if(re.test(ss)) { return
	 * true; } else { return false; } },
	 */
	/**
	 * 判断字符是否为空
	 */
	nullValidation : function(ss) {
		var re;
		re = /^\S/;
		if (re.test(ss)) {
			return true;
		} else {
			return false;
		}
	},

	/**
	 * 判断字符是否为空，判断字符长度为4
	 */
	goodsValidation : function(ss) {
		var re;
		re = /^\S{1,12}$/;
		if (re.test(ss)) {
			return true;
		} else {
			return false;
		}
	},

	/**
	 * 判断字符是否为空，判断字符长度为6-8
	 */
	signatureValidation : function(ss) {
		var re;
		re = /^\S{3,8}$/;
		if (re.test(ss)) {
			return true;
		} else {
			return false;
		}
	},

	/**
	 * 判断是否为空
	 *
	 * @param ss
	 * @returns {Boolean}
	 */
	nulValidation : function(ss) {
		var re;
		re = /^\S{1,11}$/;
		if (re.test(ss)) {
			return true;
		} else {
			return false;
		}
	},

	/* 验证邮箱 */
	emailValidation : function(ss) {
		var re;
		re = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if (re.test(ss)) {
			return true;
		} else {
			return false;
		}
	},
	urlValidation : function(ss) {
		var re;
		re = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
		if (re.test(ss)) {
			return true;
		} else {
			return false;
		}
	},

	/*
	 * 验证130-139,150-159,180-189号码段的手机号码
	 */
	phoneValidation : function(ss) {
		var re;
		re = /^1\d{10}$/;
		if (re.test(ss)) {
			return true;
		} else {
			return false;
		}
	},

	/*
	 * 验证输入的字段
	 */
	valueValidation : function(ss) {
		var re;
		re = /^[@#\$%\^&\*]+/g;
		if (re.test(ss)) {
			return false;
		} else {
			return true;
		}
	},

	/*
	 * 验证6-16位密码，只包含数字，大写字母，小写字母
	 */
	passwordValidation : function(ss) {
		var re;
		re = /^[a-zA-Z0-9]{6,16}$/;
		if (re.test(ss)) {
			return true;
		} else {
			return false;
		}
	},

	/**
	 * 验证银行卡号
	 */
	bankCarddValidation : function(ss) {
		var re;
		re = /^(\d{16}|\d{19})$/;
		if (re.test(ss)) {
			return true;
		} else {
			return false;
		}
	},
	/*
	 * 验证6位验证码，只包含0-9位数字
	 */
	captchaValidation : function(ss) {
		var re;
		re = /^\d{6}$/;
		if (re.test(ss)) {
			return true;
		} else {
			return false;
		}
	}
}

/**
 * 初始化需要执行的方法
 * @param name 传递来的方法名
 */
function method(name) {
	/** this.func = new Function(name+'();'); */
	this.func = function(){};	//初始化this.func属性,
	try{	//这里用eval方法，把我们传进来的这个方法名所代表的方法当作一个对象来赋值给method的func属性。
		this.func = eval(name);
	} catch(e) {	//如果找不到methodName这个对应的对象,则eval方法会抛异常
		alert(name+"()不存在！");
	}
}

/**
 * 从 file 域获取 本地图片 url
 */
function getFileUrl(sourceId) {
	var url;
	if (navigator.userAgent.indexOf("MSIE") >= 1) { // IE
		url = sourceId.value;
	} else if (navigator.userAgent.indexOf("Firefox") > 0) { // Firefox
		url = window.URL.createObjectURL(sourceId);
	} else if (navigator.userAgent.indexOf("Chrome") > 0) { // Chrome
		url = window.URL.createObjectURL(sourceId);
	}
	return url;
}

/**
 * 将本地图片 显示到浏览器上
 */
function preImg(sourceId, targetId, update) {
	var fileList = sourceId.files;
	var url = [];
	$.each(fileList,function(i,item){
		url[i] = getFileUrl(item);
	});
	var imgPre = document.getElementById(targetId);
	imgPre.src = url[0];
	$('#'+update).val('update');
}

/**
 * 时间格式化
 * @param time
 * @returns
 */
function getDateTime(time) {
	var datetime = new Date();
	datetime.setTime(time);
	var year = datetime.getFullYear();
	var month = datetime.getMonth() + 1 < 10 ? "0" + (datetime.getMonth() + 1)
			: datetime.getMonth() + 1;
	var date = datetime.getDate() < 10 ? "0" + datetime.getDate() : datetime
			.getDate();
	var hour = datetime.getHours() < 10 ? "0" + datetime.getHours() : datetime
			.getHours();
	var minute = datetime.getMinutes() < 10 ? "0" + datetime.getMinutes()
			: datetime.getMinutes();
	var second = datetime.getSeconds() < 10 ? "0" + datetime.getSeconds()
			: datetime.getSeconds();
	return year + "-" + month + "-" + date + " " + hour + ":" + minute + ":"
			+ second;
}
