/** 全局变量 */
var _linkDate = {}; // 折线图数据对象
var linkDate_ = {   // 折线图数据对象(初始化用)
    'title' : '-历史价格走势图', // 折线图标题
    'xaxis' : [], // x轴坐标值
    'data_a' : {'name': 'A级','data': []}, // A级价格数据
    'data_b' : {'name': 'B级','data': []}, // B级价格数据
    'data_c' : {'name': 'C级','data': []} // C级价格数据
};
var conditions = {'grade' : 'A','name' : '香樟'}; // 搜索条件
var start = 0;//第几条 从0开始
var length = 20;//每页显示数量
var show;
/** 初始执行方法 */
$(document).ready(function() {
    checkSign();
    getPriceLine('香樟');
    getTreeKind();
    show = $('#showPanel').diamonds({
        rowNumber : 5, // 行数
        colNumber : 3, // 列数
        ajax : function (param, callback) {
            if(null==param)return;
            var data = {
                'iDisplayStart' : param.startPage * param.rowNumber * param.colNumber,
                'iDisplayLength' : param.rowNumber * param.colNumber
            };
            data = $.extend({}, data, conditions || {});
            $.getAjax('/sapling/list', data, function(json){	// 获取苗木信息
        		if(json.code == 1){
                    callback(json);
        		}else{
        			swal({
        	  		  title: json.message,
        	  		  type: "error",
        	  		  timer: 1000,
        	  		  showConfirmButton: false
        			});
        		}
        	})
        }
    });
});
/** 验证登陆 */
function checkSign() {
    if($.cookie('user')) {
        $('ul.fr').empty();
        $('ul.fr').append('<li><a href="personal.html">'+$.cookie('user')+'</a></li>');
    }
}
/**
 * [trunround 旋转图片]
 * @param  {[type]} direction [方向 1左2右]
 */
function trunround(direction) {
    var pic = document.getElementById('pictureUrl');
    var reg = /\d+/g;
    var ms = pic.style.transform.match(reg);
    if(null == ms) {
        ms = 0;
    } else {
        ms = parseInt_(ms);
    }
    switch(direction) {
        case 1:pic.style.transform = 'rotate('+(ms+90)+'deg)';break;
        case 2:pic.style.transform = 'rotate('+(ms+270)+'deg)';break;
    }
}
/** 上一张图片 */
function shang(index) {
    if(index==0) {
        var buttonGroup = $('button.btn.btn-white');
        $.each(buttonGroup,function(i, item) {
            if(this.innerHTML == '<i class="fa fa-chevron-left"></i>') {
                this.click();
            }
        });
    }
}
/** 下一张图片 */
function xia(index) {
    if(index==14) {
        var buttonGroup = $('button.btn.btn-white');
        $.each(buttonGroup,function(i, item) {
            if(this.innerHTML == '<i class="fa fa-chevron-right"></i>') {
                this.click();
            }
        });
    }
}
/** 级别按钮组点击切换选中样式 */
$('.level-btn').click(function () {
    var doms = $('.level-btn');
    doms.removeClass('active');
    this.className='level-btn active';
    switch (this.innerText) {
        case '全部':conditions.grade = '';break;
        default:conditions.grade = this.innerText;break;
    }
    searchsapling();
    initPrice();
});
/**
 * [获取历史价格数据]
 * @param  {[type]} name  [树名]
 */
function getPriceLine(name){
	var param = {"name":name};
	$('#tree-name').text(name);
	$.getAjax('/util/histroyPrice', param, function(json){
		if(json.code == 1) {
            _linkDate = jQuery.extend(true,{}, linkDate_);
            _linkDate.title = name + _linkDate.title;
            $.each(json.data,function(i,item) {
                switch (item.grade) {
                    case 'A':_linkDate.data_a.data.push(parseInt_(item.minPrice));break;
                    case 'B':_linkDate.data_b.data.push(parseInt_(item.minPrice));break;
                    case 'C':_linkDate.data_c.data.push(parseInt_(item.minPrice));
                             _linkDate.xaxis.push(getDateTime(item.pricingTime).substring(0,10));break;
                }
            });
            initPrice();
		} else {
			swal({
		  		title: "价格数据获取失败",
		  		type: "error",
		  		timer: 1000,
		  		showConfirmButton: false
			});
		}
	});
}
/** 获取苗木品种 */
function getTreeKind() {
    var param = {"order":"t","isgetTotal":false};
    $.getAjax('/sapling/list', param, function(json){
		if(json.code == 1){
			$("#result").empty();
			$.each(json.data,function(i,item){
				var html = '<div class="col-sm-4 text-center mt10">'+
				'<a class="tree-name">'+item.name+'</a></div>';
				$("#result").append(html);
			});
            /** 苗木选取 */
            $('.tree-name').click(function() {
                conditions.name = this.innerText;
                searchsapling();
                getPriceLine(this.innerText);
            });
		}else{
			swal({
	  		  title: json.message,
	  		  type: "error",
	  		  timer: 1000,
	  		  showConfirmButton: false
			});
		}
	})
}
/** 初始化价格走势图 */
function initPrice() {
    /** 判断所选级别 */
    var grade = $('.level-btn.active').text();
    var data = [];
    switch (grade) {
        case 'A':data.push(_linkDate.data_a);break;
        case 'B':data.push(_linkDate.data_b);break;
        case 'C':data.push(_linkDate.data_c);break;
        default:data.push(_linkDate.data_a);
                data.push(_linkDate.data_b);
                data.push(_linkDate.data_c);break;
    }
    var title = data[0].data.length==0?'暂无数据':'';
    Highcharts.chart('price-stock', {
        title : {
            text : _linkDate.title
        },
        subtitle : {
            text : title
        },
        yAxis: {
            title: {
                text: '单价：元'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        chart: {
            zoomType: 'y',
            resetZoomButton: {
                position: {
                    x: 0,
                    y: -30
                }
            }
        },
        xAxis: {
            categories: _linkDate.xaxis
        },
        series: data
    });
}
/** 字符串转数字 */
function parseInt_(value) {
	value = parseInt(value);
	if(null == value || value == 'NaN'){
		return 0;
	}
	return value;
}
/** 全局搜索 */
function search() {
    conditions.name = $('#searchText').val();
    searchsapling();
}
/** 根据条件搜索 */
function searchsapling() {
    var param = {
        rowNumber : 5, // 行数
        colNumber : 3, // 列数
        startPage : 0
    }
    param = $.extend({}, param, conditions || {});
    show.reload(param);
}
