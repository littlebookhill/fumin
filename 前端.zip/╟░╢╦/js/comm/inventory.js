var $row;
$(document).ready(function () {
    //调用函数，初始化表格
    initTable();
    //当点击查询按钮的时候执行
    $("#search").bind("click", initTable);
});
function initTable() {
    //先销毁表格
    $('#table').bootstrapTable('destroy');
    //初始化表格,动态从服务器加载数据
    $("#table").bootstrapTable({
        method: "get",  //使用get请求到服务器获取数据
        url: "http://42.51.32.69:8080/Inventory/sapling/list", //获取数据的Servlet地址
        striped: true,  //表格显示条纹
        pagination: true, //启动分页
        sortable: false,                     //是否启用排序
        sortOrder: "asc",                   //排序方式
        clickToSelect: true,                //是否启用点击选中行
        pageSize: 15,  //每页显示的记录数
        pageNumber:1, //当前第几页
        pageList: [5, 10, 15, 20, 25],  //记录数可选列表
        search: true,  //是否启用查询
        showColumns: true,  //显示下拉框勾选要显示的列
        showRefresh: true,  //显示刷新按钮
        sidePagination: "server", //表示服务端请求
        //设置为undefined可以获取pageNumber，pageSize，searchText，sortName，sortOrder
        //设置为limit可以获取limit, offset, search, sort, order
        queryParamsType : "undefined",
        columns: [{
            field: 'id',
            title: 'ID'
        },{
            field: 'number',
            title: '编号'
        },{
            field: 'name',
            title: '树名',
            editable: {
                type: 'text',
                title: '树名',
                validate: function (v) {
                    if (!v) return '树名不能为空';
                }
            }
        },{
            field: 'size',
            title: '规格',
            editable: {
                type: 'text',
                title: '规格',
                validate: function (v) {
                    if (!v) return '规格不能为空';
                }
            }
        },{
            field: 'grade',
            title: '品级',
            editable: {
                type: 'select',
                title: '规格',
                source:[{value:"A",text:"A级"},{value:"B",text:"B级"},{value:"C",text:"C级"}]
            }
        },{
            field: 'belong',
            title: '基地',
            editable: {
                type: 'text',
                title: '基地',
                validate: function (v) {
                    if (!v) return '基地不能为空';
                }
            }
        },{
            field: 'isForbidden',
            title: '状态',
            editable: {
                type: 'select',
                title: '状态',
                source:[{value:"0",text:"在售"},{value:"1",text:"禁售"}]
            }
        }],
        onClickRow: function (row) {
            $('#panel').remove();
        },
        onDblClickRow: function (row) {
            $row = row;
        },
        onEditableSave: function (field, row, oldValue, $el) {
            $.ajax({
                type: "post",
                url: "http://42.51.32.69:8080/Inventory/sapling/edit",
                data: row,
                dataType: 'JSON',
                success: function (data, status) {
                    if (status == "success") {
                        alert('提交数据成功');
                    }
                },
                error: function () {
                    alert('编辑失败');
                },
                complete: function () {
                }
            });
        },
        queryParams: function queryParams(params) {   //设置查询参数
          var param = {
              iDisplayStart: (params.pageNumber-1)*params.pageSize,
              iDisplayLength: params.pageSize
          };
          return param;
        },
        responseHandler: function(res) {
            return {
                "total": res.recordsTotal,//总页数
                "rows": res.data   //数据
             };
        },
        onLoadSuccess: function(){  //加载成功时执行
            $("table tbody tr").dblclick(function () {
                $('#panel').remove();
                var html = '<tr id="panel"><td colspan="7"><form id="updateForm"';
                html += '<input name="id" value="'+$row.id+'">';
                html += '<input name="name" value="'+$row.name+'">';
                html += '<input name="belong" value="'+$row.belong+'">';
                html += '<input name="isForbidden" value="'+$row.isForbidden+'">';
                html += '<input name="grade" value="'+$row.grade+'">';
                html += '<input name="picture" value="'+$row.picture+'">';
                html += '<input name="size" value="'+$row.size+'">';
                html += '<input name="createTime" value="'+getDateTime($row.createTime)+'">';
                html += '<input type="button" value="保存">';
                html += '</form></td><tr>';
                var tr= $('<tr id="panel"><td colspan="7" >1.1</td></tr>');
                $($(this)[0]).after($(html));
            });
        },
        onLoadError: function(){  //加载失败时执行
          alert("加载数据失败");
        }
    });
}
