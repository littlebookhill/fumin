$(document).ready(function () {
    getFourDatas();
    getFlotDatas();
    getPriceLine('香樟');
});

/** 获取首页上方四个小面板的数据 */
function getFourDatas() {
    $.getAjax('/util/getTotal', {}, function(json){
        if(json.code == 1){
            var obj = $('h1.no-margins');
            $.each(json.data,function (i,item) {
                obj[i].innerText = (null==item?'0':item.totalNumber);
            });
        } else {
			swal({
    	  		title: "销售数据获取失败",
    	  		type: "error",
	  		    timer: 1000,
	  		    showConfirmButton: false
			});
		}
    })
}
/** 获取柱状图表数据 */
function getFlotDatas() {
    var myDate = new Date(); //获取今天日期
    var year = myDate.getFullYear(), month = myDate.getMonth();
    var maxDay = new Date(year,month,0).getDate();
    var param = {'status':'2','month':(year+'-'+month+'-01'),'month1':(year+'-'+month+'-'+maxDay)};
    var orderDatas = [], moneyDatas = [];
    var orderCount = 0, moneyCount = 0;
    var obj = $('h2.no-margins'), div = $('div.stat-percent'), div1 = $('div.progress-bar');
    $.getAjax('/util/getOrderDatas', {}, function(json){
        if(json.code == 1){
            var order = 0, price = 0;
            var newDom = document.createElement('i'), newDom1 = document.createElement('i'), newDom2 = document.createElement('i');
            newDom.className = 'fa fa-level-up text-navy';
            newDom1.className = 'fa fa-level-up text-navy';
            newDom2.className = 'fa fa-level-up text-navy';
            $.each(json.data,function(i,item){
                switch (i) {
                    case 0:order = item.totalNumber;break;
                    case 1:obj[0].innerText = item.totalNumber;
                        order!=0&&(div[0].innerText=(item.totalNumber/order-1)*100+'%',
                        div[0].appendChild(newDom)),div1[0].style='width:'+(item.totalNumber/order-1)*100+'%';break;
                    case 2:order = item.orderCount;price = item.getPrice;break;
                    case 3:obj[1].innerText = item.orderCount;
                        order!=0&&(div[1].innerText=(item.orderCount/order-1)*100+'%',
                        div[1].appendChild(newDom1)),div1[1].style='width:'+(item.orderCount/order-1)*100+'%';
                        obj[2].innerText = (item.getPrice==null?0:item.getPrice);
                        order!=0&&(div[2].innerText=(item.getPrice/price-1)*100+'%',
                        div[2].appendChild(newDom2)),div1[2].style='width:'+(item.getPrice/price-1)*100+'%';break;
                }
            });
        }
    });
    $.getAjax('/order/getLine', param, function(json){
        if(json.code == 1){
            for (var i = 1; i <= maxDay; i++) {
                var orderDatas_ = [], moneyDatas_ = [];
                orderDatas_.push(gd(year+'-'+month+'-'+plusZero(i,2)));
                moneyDatas_.push(gd(year+'-'+month+'-'+plusZero(i,2)));
                $.each(json.data,function(j,item){
                    if (orderDatas_[0] == gd(item.dates)) {
                        orderDatas_.push(item.orderCount);
                        moneyDatas_.push(item.getPrice);
                    }
                });
                orderDatas.push(orderDatas_);
                moneyDatas.push(moneyDatas_);
            }
            $.each(json.data,function(j,item){
                orderCount += item.orderCount;
                moneyCount += item.getPrice;
            });
            initFlot(orderDatas, moneyDatas);
        } else {
			swal({
    	  		title: "订单数据获取失败",
    	  		type: "error",
	  		    timer: 1000,
	  		    showConfirmButton: false
			});
		}
    });
}
/**
 * 初始化柱状表
 * @param  {[type]} orderDatas [订单数量]
 * @param  {[type]} moneyDatas [订单金额]
 */
function initFlot(orderDatas, moneyDatas) {
    var dataset = [
        {
            label: "订单金额",
            data: moneyDatas,
            color: "#1ab394",
            bars: {
                show: true,
                align: "center",
                barWidth: 24 * 60 * 60 * 600,
                lineWidth: 0
            }

        }, {
            label: "订单数",
            data: orderDatas,
            yaxis: 2,
            color: "#464f88",
            lines: {
                lineWidth: 1,
                show: true,
                fill: true,
                fillColor: {
                    colors: [{
                        opacity: 0.2
                    }, {
                        opacity: 0.2
                    }]
                }
            },
            splines: {
                show: false,
                tension: 0.6,
                lineWidth: 1,
                fill: 0.1
            },
        }
    ];

    var options = {
        xaxis: {
            mode: "time",
            tickSize: [3, "day"],
            tickLength: 0,
            axisLabel: "Date",
            axisLabelUseCanvas: true,
            axisLabelFontSizePixels: 12,
            axisLabelFontFamily: 'Arial',
            axisLabelPadding: 10,
            color: "#838383"
        },
        yaxes: [{
                position: "left",
                color: "#838383",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Arial',
                axisLabelPadding: 3
        }, {
                position: "right",
                clolor: "#838383",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: ' Arial',
                axisLabelPadding: 67
        }
        ],
        legend: {
            noColumns: 1,
            labelBoxBorderColor: "#000000",
            position: "nw"
        },
        grid: {
            hoverable: false,
            borderWidth: 0,
            color: '#838383'
        }
    };

    $.plot($("#flot-dashboard-chart"), dataset, options);
}
/** 将字符串时间转化为时间戳 */
function gd(date) {
    date = new Date(Date.parse(date.replace(/-/g, "/")));
    return date.getTime();
}
/** 转化数字 */
function aa(value) {
	value = parseInt(value);
	if(value == null){
		return 0;
	}
	return value;
}
//获取历史价格数据
function getPriceLine(name){
	var param = {"name":name};
	$('#tree-name').text(name);
	$.getAjax('/util/histroyPrice', param, function(json){
		if(json.code == 1) {
			var price = {
				maxa:0,maxb:0,maxc:0,
				mina:99999999,minb:99999999,minc:99999999
			}
			var a=[],b=[],c=[],a1=[],b1=[],c1=[],x=[];
			var data = json.data;
			for(var i=0; i<data.length||initPriceLine(a,b,c,a1,b1,c1,x,price); i=i+3) {
				a.push(aa(data[i].maxPrice));
				b.push(aa(data[i+1].maxPrice));
				c.push(aa(data[i+2].maxPrice));
				a1.push(-aa(data[i].minPrice));
				b1.push(-aa(data[i+1].minPrice));
				c1.push(-aa(data[i+2].minPrice));
				x.push(getDateTime(data[i].pricingTime).substring(0,10));
				aa(data[i].maxPrice)>price.maxa&&(price.maxa=aa(data[i].maxPrice));
				aa(data[i+1].maxPrice)>price.maxb&&(price.maxb=aa(data[i+1].maxPrice));
				aa(data[i+2].maxPrice)>price.maxc&&(price.maxc=aa(data[i+2].maxPrice));
				aa(data[i].minPrice)<price.mina&&(price.mina=aa(data[i].minPrice));
				aa(data[i+1].minPrice)<price.minb&&(price.minb=aa(data[i+1].minPrice));
				aa(data[i+2].minPrice)<price.minc&&(price.minc=aa(data[i+2].minPrice));
			}
		} else {
			swal({
		  		title: "价格数据获取失败",
		  		type: "error",
		  		timer: 1000,
		  		showConfirmButton: false
			});
		}
	});
}
$('#search-btn').click(function() {
	getPriceLine($('#tree-name-search').val());
});
//初始化价格折线图
function initPriceLine(a,b,c,a1,b1,c1,x,price) {
	$('#max-A').text(price.maxa);$('#max-B').text(price.maxb);$('#max-C').text(price.maxc);
	$('#min-A').text(price.mina);$('#min-B').text(price.minb);$('#min-C').text(price.minc);
	$('#priceLine').highcharts({
        title: {
            text: '树苗历史价格折线图',
            x: -20 //center
        },
        subtitle: {
        },
        xAxis: {
            categories: x,
            min:0,
            max:10
        },
        scrollbar : {
            enabled:true
        },
        yAxis: {
            title: {
                text: '单价：元'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ''
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },
        series: [{
            name: 'A级最高价',
            data: a
        }, {
            name: 'B级最高价',
            data: b
        }, {
            name: 'C级最高价',
            data: c
        }, {
            name: 'A级最低价',
            data: a1
        }, {
            name: 'B级最低价',
            data: b1
        }, {
            name: 'C级最低价',
            data: c1
        }]
    });
}
