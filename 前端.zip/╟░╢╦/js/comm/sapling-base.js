/* Init DataTables */
var oTable = null;
$(document).ready(function () {
    // 填充数据
    initDatas();
    // 数据修改
    setTimeout(function(){
        updateData();
    },1000);
})
/** 填充数据 */
function initDatas() {
    oTable = $('#editable').dataTable({
        ajax : function(data, callback, settings) {
                //封装请求参数
                var param = userManage.getQueryCondition(data);
                $.getAjax('/basearea/list', param, function(json){
                    if(json.code == 1){
                        //封装返回数据
                        var returnData = {};
                        returnData.draw = json.draw;//这里直接自行返回了draw计数器,应该由后台返回
                        returnData.recordsTotal = json.iDisplayLength;//当前页记录数
                        returnData.recordsFiltered = json.recordsTotal;//总记录数
                        returnData.data = json.data;
                        //调用DataTables提供的callback方法，代表数据已封装完成并传回DataTables进行渲染
                        //此时的数据需确保正确无误，异常判断应在执行此回调前自行处理完毕
                        callback(returnData);
                    } else {
            			swal({
                	  		title: "基地数据获取失败",
                	  		type: "error",
            	  		    timer: 1000,
            	  		    showConfirmButton: false
            			});
            		}
                });
            },
        "destroy": true,
    	"columns": [
			{"data" : "id"},
            {"data" : "name"},
            {"data" : "province"},
            {"data" : "city"},
            {"data" : "country"},
            {"data" : "street"},
            {"data" : "houseNumber"}
    	]
    });
}
/** 数据修改 */
function updateData() {
    oTable.$('td').editable('http://localhost:8080/Inventory/basearea/edit', {
        "callback": function (sValue, y) {
            // sValue 返回的json字符串
            // y 对应表格框
            var aPos = oTable.fnGetPosition(this);
            var param = JSON.parse(sValue);	// 转换为对象
            oTable.fnUpdate(param.data, aPos[0], aPos[1]);
        },
        "submitdata": function (value, settings) {  //参数
            // value 表格原有值
            // settings 对应表格框
            var row = oTable.fnGetPosition(this)[0];
            var column = oTable.fnGetPosition(this)[1];
            var param = {"id": oTable.fnGetData(row).id};
            switch (column) {
                case 0:param.colName='id';break;
                case 1:param.colName='name';break;
                case 2:param.colName='province';break;
                case 3:param.colName='city';break;
                case 4:param.colName='country';break;
                case 5:param.colName='street';break;
                case 6:param.colName='house_number';break;
            }
            return param;
        },
        "width": "100%",
        "height": "100%"
    });
}
//组装分页参数
var userManage = {
    getQueryCondition : function(data) {
        var param = {};
        param.iDisplayStart = data.start;
        param.iDisplayLength = data.length;
        return param;
    }
};
setTimeout(function () {
    /** 翻页按钮组 */
    var pageBtn = $('.paginate_button');
    pageBtn[1].children[0].className = 'active';
    $('#editable_previous').removeClass('disabled');

    /** 上一页 */
    $('#editable_previous').click(function () {
        var dom = $('a.active')[0];
        var page = parseInt(dom.innerText);
        if(1==page){return};
        var doms = $('a');
        $.each(doms,function(i,item) {
            (page-1)==item.innerText&&(item.className='active');
        });
        dom.className = '';
    });
    /** 下一页 */
    $('#editable_next').click(function () {
        var dom = $('a.active')[0];
        var doms = $('a');
        var page = parseInt(dom.innerText);
        if(doms[doms.length-2].innerText==page){return};
        var doms = $('a');
        $.each(doms,function(i,item) {
            (page+1)==item.innerText&&(item.className='active');
        });
        dom.className = '';
    });
},2500);
