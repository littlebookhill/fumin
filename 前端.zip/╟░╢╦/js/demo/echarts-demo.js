$(function () {
    initLine_day();
    initLine_month(null,null);
    initLine_year(null);
    initMap_datas();

    $('#m_minus').click(function () {
        var month = minus($('#m_month').val());
        $('#m_month').val(plusZero(month,2));
        if(12 == month) {
            $('#m_year').val(parseInt($('#m_year').val())-1);
        }
        initLine_month($('#m_year').val(), $('#m_month').val());
    });
    $('#m_plus').click(function () {
        var month = plus($('#m_year').val(), $('#m_month').val());
        $('#m_month').val(plusZero(month,2));
        if(1 == month) {
            $('#m_year').val(parseInt($('#m_year').val())+1);
        }
        initLine_month($('#m_year').val(), $('#m_month').val());
    });
    $('#y_minus').click(function () {
        $('#y_year').val(parseInt($('#y_year').val())-1);
        initLine_year($('#y_year').val());
    });
    $('#y_plus').click(function () {
        $('#y_year').val(plus($('#y_year').val(), 0));
        initLine_year($('#y_year').val());
    });
    $('#m_month').blur(function () {
        $('#m_month').val(plusZero($('#m_month').val(),2));
        initLine_month($('#m_year').val(), $('#m_month').val());
    });
    $('#m_year').blur(function () {
        initLine_month($('#m_year').val(), $('#m_month').val());
    });
    $('#y_year').blur(function () {
        initLine_year($('#y_year').val());
    });
});
/** 最近七日数据折线图 */
function initLine_day() {
    var myDate = new Date(); //获取今天日期
    myDate.setDate(myDate.getDate() - 6);
    var dateArray = [];
    var dateTemp;
    for (var i = 0; i < 7; i++) {
        dateTemp = myDate.getFullYear()+"-"+plusZero((myDate.getMonth()+1),2)+"-"+plusZero(myDate.getDate(),2);
        dateArray.push(dateTemp);
        myDate.setDate(myDate.getDate() + 1);
    }
    var param = {'status':'1'};
    $.getAjax('/order/getLine', param, function(json){
        if(json.code == 1){
            var values =  Array.from(new Int8Array(7));
            var values_ =  Array.from(new Int8Array(7));
            $.each(json.data,function(i,item){
                for (var index in dateArray) {
                    if (dateArray[index] == item.dates) {
                        values[index] = item.orderCount;
                        values_[index] = item.getPrice;
                    }
                }
            });
            initLine("day_line", '最近七日数据统计', dateArray, values,1);
            initLine("day_line_", '最近七日数据统计', dateArray, values_,2);
        } else {
			swal({
    	  		title: "销售数据获取失败",
    	  		type: "error",
	  		    timer: 1000,
	  		    showConfirmButton: false
			});
		}
    });
}
/**
 *月数据折线图
 *year 年
 *month 月
 */
function initLine_month(year, month) {
    var x_axis = [],values,values_,title = year+'年'+month+'月数据统计';
    var param = {'status':'2','month':(year+'-'+month+'-01')};
    if (null == year) {
        var myDate = new Date(); //获取今天日期
        var day = new Date(myDate.getFullYear(),(myDate.getMonth() + 1),0);
        for (var i = 0; i < day.getDate(); i++) {
            x_axis.push(i+1);
        }
        title = myDate.getFullYear()+'年'+(myDate.getMonth() + 1)+'月数据统计';
        values = Array.from(new Int8Array(myDate.getDate()));
        values_ = Array.from(new Int8Array(myDate.getDate()));
        param.month = myDate.getFullYear()+'-'+(myDate.getMonth() + 1)+'-01';
        param.month1 = myDate.getFullYear()+'-'+(myDate.getMonth() + 1)+'-'+plusZero(myDate.getDate()+1,2);
    } else {
        var day = new Date(year,month,0);
        for (var i = 0; i < day.getDate(); i++) {
            x_axis.push(i+1);
        }
        values = Array.from(new Int8Array(day.getDate()));
        values_ = Array.from(new Int8Array(myDate.getDate()));
        param.month1 = year+'-'+month+'-'+(day.getDate()+1);
    }
    $.getAjax('/order/getLine', param, function(json){
        if(json.code == 1){
            $.each(json.data,function(i,item){
                for (var index in x_axis) {
                    if (x_axis[index] == item.dates.substring(8)) {
                        values[index] = item.orderCount;
                        values_[index] = item.getPrice;
                    }
                }
            });
            initLine("month_line", title, x_axis, values,1);
            initLine("month_line_", title, x_axis, values_,2);
        } else {
			swal({
    	  		title: "销售数据获取失败",
    	  		type: "error",
	  		    timer: 1000,
	  		    showConfirmButton: false
			});
		}
    });
}
/**
 *年数据折线图
 *year 年
 */
function initLine_year(year) {
    var myDate = new Date(); //获取今天日期
    if (null == year) {
        year = myDate.getFullYear();
    }
    var len = (year==myDate.getFullYear()?(myDate.getMonth()+1):12);
    var x_axis=[1,2,3,4,5,6,7,8,9,10,11,12],values=Array.from(new Int8Array(len)),
        values_=Array.from(new Int8Array(len)),title = year+'年数据统计';
    var param = {'status':'3','year':(year+'-01'),'year1':(year+'-12')};
    $.getAjax('/order/getLine', param, function(json){
        if(json.code == 1){
            $.each(json.data,function(i,item){
                for (var index in x_axis) {
                    if (x_axis[index] == item.dates.substring(5)) {
                        values[index] = item.orderCount;
                        values_[index] = item.getPrice;
                    }
                }
            });
            initLine("year_line", title, x_axis, values,1);
            initLine("year_line_", title, x_axis, values_,2);
        } else {
			swal({
    	  		title: "销售数据获取失败",
    	  		type: "error",
	  		    timer: 1000,
	  		    showConfirmButton: false
			});
		}
    });
}
/** 获取地图数据 */
function initMap_datas() {
    $.getAjax('/util/getOrderAddress', {}, function(json){
        if(json.code == 1){
            var datas=[],data;
            $.each(json.data,function(i,item){
                data = {name: item.province,value: item.totalNumber};
                datas.push(data);
            });
            initMap(datas);
        } else {
			swal({
    	  		title: "销售数据获取失败",
    	  		type: "error",
	  		    timer: 1000,
	  		    showConfirmButton: false
			});
		}
    })
}
/**
 *初始化地图
 *datas 数据
 */
function initMap(datas) {
    var mapChart = echarts.init(document.getElementById("echarts-map-chart"));
    var mapoption = {
        title : {
            text: '订单数量',
            x:'center'
        },
        tooltip : {
            trigger: 'item'
        },
        legend: {
            orient: 'vertical',
            x:'left',
            data:['订单']
        },
        dataRange: {
            min: 0,
            max: 2500,
            x: 'left',
            y: 'bottom',
            text:['高','低'],           // 文本，默认为数值文本
            calculable : true
        },
        toolbox: {
            show: true,
            orient : 'vertical',
            x: 'right',
            y: 'center',
            feature : {
                mark : {show: true},
                dataView : {show: true, readOnly: false},
                restore : {show: true},
                saveAsImage : {show: true}
            }
        },
        roamController: {
            show: true,
            x: 'right',
            mapTypeControl: {
                'china': true
            }
        },
        series : [
            {
                name: '订单',
                type: 'map',
                mapType: 'china',
                itemStyle:{
                    normal:{label:{show:true}},
                    emphasis:{label:{show:true}}
                },
                data:datas
            }
        ]
    };
    mapChart.setOption(mapoption);
    $(window).resize(mapChart.resize);
}
/**
 *初始化折线图
 *target_id 目标id
 *x_axis x轴坐标
 *values 数据
 *status 1：数量  2：金额
 */
function initLine(target_id, title, x_axis, values, status) {
    var lineChart = echarts.init(document.getElementById(target_id));
    var lineoption = {
        title : {
            text: title
        },
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            data:[(status==1?'订单数量':'订单金额')]
        },
        grid:{
            x:40,
            x2:40,
            y2:24
        },
        calculable : true,
        xAxis : [
            {
                type : 'category',
                boundaryGap : false,
                data : x_axis
            }
        ],
        yAxis : [
            {
                type : 'value',
                axisLabel : {
                    formatter: '{value} '+(status==1?'单':'元')
                }
            }
        ],
        series : [
            {
                name : (status==1?'订单数量':'订单金额'),
                type : 'line',
                data : values
            }
        ]
    };
    lineChart.setOption(lineoption);
    $(window).resize(lineChart.resize);
}
/**
 *减 1
 *num 数字
 */
function minus(num) {
    if(1 == num) {
        return 12;
    }
    return parseInt(num) - 1;
}
 /**
  *加 1
  *num 数字
  */
function plus(year, month) {
    var myDate = new Date(); //获取今天日期
    var year_ = myDate.getFullYear(), month_ = myDate.getMonth() + 1;
    if(0 == month) {
        if(year == year_) {
            return year;
        }
        return parseInt(year) + 1;
    }
    if(12 == month) {
        if(year == year_) {
            return 12;
        }
        return 1;
    }
    if(month == month_) {
        return month;
    }
    return parseInt(month) + 1;
 }
