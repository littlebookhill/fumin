/**
 * 用于显示数据所用
 * 需要 jQuery.js, bootstrap.js, bootstrap.css, font-awesome.css 支持
 * table() 以表格形式展示
 *      要求：html中写好table架构
 *              <table><thead><tr><td>列名</td></tr></thead><tbody></tbody></table>
 * diamonds() 以方块形式展示
 */
(function ($) {
    var tableSettings = {};//表格形式的默认设置
    var diamondsSettings = {
        rowNumber : 5,//行数
        colNumber : 4,//列数
        startPage : 0,//起始页 0为第1页
        countData : 0,//数据数量总计
        ajax : function () {}
    };//方块形式的默认设置
    var _thisId = '';
    var _options;
    var viewer;
    $.fn.diamonds = function (options) {
        _options = $.extend({}, diamondsSettings, options || {});
        var $this = this; // 获取对象
        _thisId = $this.attr("id"); // 获取对象id
        addStyle(); // 自定义css样式
        $this.append('<div class="row"></div>'); // 分行 次行内显示数据
        $this.append('<div class="row"></div>'); // 分行 次行内显示分页按钮
        _options.ajax(_options, dcallback); // 执行回掉函数
        return {
            reload: function (param){
                searchforcondition(param);
            },
            viewer
        };
    };
    /** 自定义css样式 */
    function addStyle() {
        var styleHead = '<style>';
        var styleBody = '.ds-nodata-tip{text-align:center;font-size:50px;}'+
                        '.d_img{width: 100%;height: 205px;}'+
                        '.texiao:hover{zoom:110%;}';
        var styleEnd = '</style>';
        if ($('style').length==0) $('head').append(styleHead+styleBody+styleEnd);
        if ($('style').length!=0) $('style').append(styleBody);
    }
    /**
     * [dcallback 以方块形式展示的回掉函数]
     * @param  {[type]}   data [数据]
     * 格式 ： data {
     *          startPage : number, [起始页]
     *          rowNumber : number, [行数]
     *          colNumber : number, [列数]
     *          countData : number, [总计数量]
     *          data : {} //数据
     *          }
     */
    function dcallback(data) {
        data.colNumber = _options.colNumber;
        data.rowNumber = _options.rowNumber;
        switch (data.colNumber) { // 检查列数
            case 1:break;case 2:break;case 3:break;case 4:break;case 6:break;
            default:throw '请输入以下列数(1,2,3,4,6)';break;
        }
        if(data.rowNumber<1)data.rowNumber=5; // 检查行数
        if(data.countData==0)if(!showZero())return; // 检查数据是否为空
        //需要修改完善起始页与开始条数
        initPageBtn((data.startPage/(_options.rowNumber*_options.colNumber)), data.rowNumber, data.colNumber, data.countData); // 初始化按钮组
        initDataShow(data.data); // 初始化显示卡片
    }
    /**
     * [initDataShow 初始化显示面板]
     * @param  {[type]} data [要显示的数据]
     */
    function initDataShow(data) {
        $('#'+_thisId)[0].children[0].innerHTML = '';
        $('#'+_thisId)[0].children[0].className = 'row';
        $.each(data,function(i,item) {
            generateShowPanel(item); // 生成数据展示版面
        });
        viewer = $('#showPanel').viewer({
            url:"data-original"
        });
        $("#showPanel").viewer('update');
    }
    /**
     * [functionName 生成数据展示版面]
     * @param  {[type]} data [展示数据]
     */
    function generateShowPanel(data) {
        var head = 'http://42.51.32.69:8080';
        var picture = data.picture;
    	var picture_s = picture.replace("picture","picture-s");
    	var introduce = '<p>树名：'+data.name+'</i></p><p>编号：'+data.number+'</i></p>'+
    			'<p>尺寸：'+data.size+'</i></p><p>地址：'+data.belong+'</i></p>'+
    			'<p>品级：'+data.grade+'</i></p><p>价格：<br>'+data.minPrice+'-'+data.maxPrice+'</i></p>';
    	var html = '<div class="col-lg-4 texiao">'+
    			'<div class="contact-box" style="border-color: '+
    			(data.isForbidden==0?'':'red')+'">'+
    			'<div class="col-sm-7">'+
    			'<div class="text-center">'+
    			'<img data-original="'+head+picture+'" alt="'+data.id+'" class="d_img" src="'+
    			head+picture_s+'"></div></div><div class="col-sm-5">'+introduce+
    			'</div>'+
    			'<div class="clearfix"></div>'+
    			'</div>'+
    			'</div>';
        $('#'+_thisId)[0].children[0].innerHTML = $('#'+_thisId)[0].children[0].innerHTML + html;
    }
    /** 数据为空时显示提示语 */
    function showZero() {
        $('#'+_thisId)[0].children[0].className = 'row ds-nodata-tip';
        $('#'+_thisId)[0].children[0].innerText = '暂无数据';
        return false;
    }
    /**
     * [initPageBtn 初始化按钮组]
     * @param  {[type]} startPage   [起始页]
     * @param  {[type]} rowNumber   [行数]
     * @param  {[type]} colNumber   [列数]
     * @param  {[type]} count [总计数量]
     */
    function initPageBtn(startPage, rowNumber, colNumber, count) {
        var countShow = rowNumber*colNumber; // 每页显示数据数量
        var countBtn = Math.ceil(count/countShow); // 按钮数量 ceil(向上取整)
        var btnGroup = generatePageBtn(startPage+1, countBtn); // 生成按钮组
        $('#'+_thisId)[0].children[1].innerHTML='<div class="fr btn-group">'+btnGroup+'</div>';
        initPageBtnClickListen(countBtn); // 初始化按钮组监听事件
    }
    /**
     * [generatePageBtn 生成按钮组]
     * @param  {[type]} startPage   [起始页]
     * @param  {[type]} pageNumber [页数]
     * @return {[type]}       [String]
     */
    function generatePageBtn(startPage, pageNumber) {
        var skewing = 0; // 按钮偏移量
        var hideBtn = pageNumber-5>=0?pageNumber-5:0; // 隐藏的按钮数量
        if(startPage>3)skewing=startPage-3>hideBtn?hideBtn:startPage-3; // 根据起始按钮获取偏移量，最大不能超过隐藏的按钮数量
        var headBtn = '<button class="btn btn-white">首页</button>'; // 首页
        var endBtn = '<button class="btn btn-white">尾页</button>'; // 尾页
        var leftBtn = '<button class="btn btn-white"><i class="fa fa-chevron-left"></i></button>'; // 向前翻页按钮
        var rightBtn = '<button class="btn btn-white"><i class="fa fa-chevron-right"></i></button>'; // 向后翻页按钮
        var middleBtn = ''; // 中间按钮
        for (var i = 1; i <= pageNumber; i++) {
            middleBtn += '<button class="btn btn-white '+((i+skewing)==startPage?'active':'')+'">'+(i+skewing)+'</button>';
            if(i==5)break;
        }
        return headBtn+leftBtn+middleBtn+rightBtn+endBtn;
    }
    /**
     * [initPageBtnClickListen 初始化按钮组监听事件]
     * @param  {[type]} pageNumber [页数]
     */
    function initPageBtnClickListen(pageNumber) {
        var btnDom = $('.fr.btn-group');
        btnDom.find('.btn.btn-white').click(function() {
            var index = parseInt(btnDom.find('.btn.btn-white.active')[0].innerHTML); // 获取当前页码
            switch (this.innerHTML) {
                case '首页':_options.startPage=0;_options.ajax(_options, dcallback);break; // 执行回掉函数
                case '尾页':_options.startPage=pageNumber-1;_options.ajax(_options, dcallback);break; // 执行回掉函数
                case '<i class="fa fa-chevron-left"></i>':
                    if(index-2>=0){
                        _options.startPage=index-2;
                        _options.ajax(_options, dcallback); // 执行回掉函数
                    };break;
                case '<i class="fa fa-chevron-right"></i>':
                    if(index<=pageNumber-1){
                        _options.startPage=index;
                        _options.ajax(_options, dcallback); // 执行回掉函数
                    };break;
                default:_options.startPage=this.innerHTML-1;_options.ajax(_options, dcallback);break; // 执行回掉函数
            }
        });
    }
    /**
     * [searchforcondition 根据条件搜索]
     * @param  {[type]} param [条件参数]
     */
    function searchforcondition(param) {
        _options.ajax(param, dcallback); // 执行回掉函数
    }
})(jQuery);
